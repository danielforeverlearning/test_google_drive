
/*!
 * Common test dependencies.
 */

// expose the globals that are obtained through `<script>` on the browser
expect = require('../expect')
