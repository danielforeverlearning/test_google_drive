// Load in the modules to test the endpoints
define([
	'./api',
	'./apiMe',
	'./apiMeAlbum',
	'./apiMeAlbums',
	'./apiMeFriends',
	'./apiMePhotos'
], function() {
	// Done
});
