# Samples of using the [Google APIs Client Library for Java](https://github.com/google/google-api-java-client)
For a complete list of Google APIs, visit https://developers.google.com/api-client-library/java/apis/
